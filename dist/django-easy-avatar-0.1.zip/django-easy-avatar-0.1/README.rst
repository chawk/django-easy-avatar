django-easy-avatar
==================

A super easy AJAX loading avatar for profile management.