from django.conf.urls import patterns, include, url

urlpatterns = patterns('',
    # Examples:
    url(r'^upload/$', 'easy_avatar.views.upload'),
)